            <aside class="col-md-2">
                <div class="panel panel-info">
                    <div class="panel-heading">Continents</div>
                    <ul class="list-group">
                        <?php
                        /* display list of continents from continents table 
                           <li class="list-group-item"><a href="#"></a></li>  */

                        ?>
                    </ul>
                </div>
                <!-- end continents panel -->

                <div class="panel panel-info">
                    <div class="panel-heading">Popular</div>
                    <ul class="list-group">
                       <?php                         
                           /* display list of countries from countries table 
                           <li class="list-group-item"><a href="#"></a></li>  */
                        ?>
                    </ul>
                </div>
                <!-- end continents panel -->
            </aside>