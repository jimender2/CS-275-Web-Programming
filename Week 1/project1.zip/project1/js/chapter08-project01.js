/* add loop and other code here ... in this simple exercise we are not
   going to concern ourselves with minimizing globals, etc */

