<?php
/*
   Represents a Location on the earth 
 */


?>