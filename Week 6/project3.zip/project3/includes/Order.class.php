<?php
/*
   Represents a Order (for the book case)
 */

?>