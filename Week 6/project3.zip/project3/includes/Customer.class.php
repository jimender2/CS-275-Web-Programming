<?php
/*
   Represents a Customer (for the book case)
 */


?>