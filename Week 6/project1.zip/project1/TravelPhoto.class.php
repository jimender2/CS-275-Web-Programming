<?php
/*
   Represents a single travel photo
 */


?>